function playVideo() {
    const url = document.getElementById('videoUrl').value;
    const playerDiv = document.getElementById('player');
    if (url.includes("youtube.com") || url.includes("youtu.be")) {
        let videoId = "";
        if (url.includes("v=")) {
            videoId = url.split("v=")[1].split("&")[0];
        } else if (url.includes("youtu.be/")) {
            videoId = url.split("youtu.be/")[1].split("?")[0];
        }
        playerDiv.innerHTML = `<iframe width="100%" height="400" src="https://www.youtube.com/embed/${videoId}" frameborder="0" allowfullscreen></iframe>`;
    } else {
        playerDiv.innerHTML = "<p style='color:red;'>❌ Invalid YouTube link</p>";
    }

    document.getElementById('subtitles').innerText = "⚠ Subtitles fetching not implemented (demo only).";
}

function speakText() {
    const text = document.getElementById('subtitles').innerText;
    const lang = document.getElementById('language').value;
    let utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === "ur" ? "ur-PK" : lang === "hi" ? "hi-IN" : "en-US";
    speechSynthesis.speak(utterance);
}
